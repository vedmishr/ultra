package com.cg.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.bean.Employee;
import com.cg.app.dao.EmployeeDao;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
 @Autowired
 private EmployeeDao employeeDao;

 public List<Employee> getEmployees() {
  List<Employee> employee = employeeDao.getEmployees();
  return employee;
 }

 public Employee getEmployee(Long employeeId) {
  Employee employee = employeeDao.getEmployee(employeeId);
  return employee;
 }

 public int deleteEmployee(Long employeeId) {
  return employeeDao.deleteEmployee(employeeId);
 }

 public int updateEmployee(Employee employee) {
  return employeeDao.updateEmployee(employee);
 }

 public int createEmployee(Employee employee) {
  return employeeDao.createEmployee(employee);
 }
}