DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS authorities;
DROP TABLE IF EXISTS users;


CREATE TABLE employees (
  empId VARCHAR2(40) NOT NULL,
  empName VARCHAR2(40) NOT NULL
);
 enabled BOOLEAN NOT NULL
create table users (
    username varchar2(50) NOT NULL PRIMARY KEY,
    password varchar2(120) NOT NULL
   
);
ALTER TABLE users ADD ENABLED NUMBER DEFAULT 1; 
DESC USERS;
select * from authorities;
SELECT * FROM USERS;
alter table users add enabled varchar2(15) default 'TRUE';
create table authorities (
    username varchar2(50) not null,
    authority varchar2(50) not null,
    foreign key (username) references users (username)
);

 insert into users(username, password)values('user','user');
 insert into authorities(username,authority)values('admin','ROLE_ADMIN');
 insert into authorities(username,authority)values('admin','ROLE_USER');
 insert into users(username, password)values('admin','admin');
 insert into authorities(username,authority)values('user','ROLE_USER');